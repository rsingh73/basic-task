import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  users = [
    {
      firstName: "Ravi",
      lastName: "Kant",
      company: "DXC",
      email: "ravi@gmail.com",
      mobile: "9993274567"
    }
  ]
  index: number
  editMode = false;
  addmode = false
  // title = 'assignment';
  registerForm: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            firstName: [''],
            lastName: [''],
            company: [''],
            email: [''],
            mobile: ['']
        });
    }

    get f() { return this.registerForm.controls; }

    onSubmit() {
       this.addmode = true
    }

    addContact() {
      this.addmode = true
    }

    editUser(user, i) {
      this.editMode = true;
      this.index = i;
      console.log(user);
      this.f.firstName.setValue(user.firstName);
      this.f.lastName.setValue(user.lastName);
      this.f.company.setValue(user.company);
      this.f.email.setValue(user.email);
      this.f.mobile.setValue(user.mobile);
    }

    cancel() {
      this.registerForm.reset();
      this.editMode = false
    }

    done() {
      console.log(this.editMode)
      console.log(this.registerForm.value)
      if (this.editMode) {
      this.users.splice(this.index, 1)
      }
      this.users.push(this.registerForm.value)
      this.registerForm.reset()
      this.editMode = false
      
    }
 
    delete(i) {
       this.users.splice(i, 1)
    }

    search(event) {
      console.log(event.target.value)
      let filtered;
       filtered = this.users.filter((name) => {
        return name.firstName === event.target.value
      })
      console.log(filtered)
      if (filtered.length !== 0){
      this.users = filtered;
      }
    }


}
